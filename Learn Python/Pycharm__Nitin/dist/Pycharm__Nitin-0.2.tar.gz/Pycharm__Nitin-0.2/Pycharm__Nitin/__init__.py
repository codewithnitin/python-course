
def achafunc(a):
    print("This is a function")
    return(a)