
# def achafunc(a):
#     print("This is a function")
#     return(a)

class Improvement_module:
    def __init__(self):
        print("Constructor ban gaya atti uttam :)")

    def achafunc(self, a):
        print("This is a function")
        return(a)