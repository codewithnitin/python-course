
# from setuptools import setup
#
# setup(name = "Pycharm__Nitin",
#       version = 0.2,
#       description = "This is a module which is made by code with Nitin",
#       author = "Nitin",
#       packages = ["Pycharm__Nitin"],
#       install_requires = [])



from setuptools import setup

setup(name = "Pycharm__Nitin",
      version = 0.4,
      description = "This is a module which is made by code with Nitin",
      author = "Nitin",
      packages = ["Pycharm__Nitin"],
      install_requires = [])